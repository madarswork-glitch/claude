Patternflow - Neon pack (landscape, 128 x 64)

10 patterns, in running order:
  Warp Tunnel      knobs: speed / twist / curve / palette
  Tesseract        knobs: spin / distance / trails / palette
  Kaleido Glass    knobs: spin / mirrors / zoom / palette
  Spiral Galaxy    knobs: spin / tilt / distance / palette
  Outrun           knobs: speed / sun / curve / palette
  Lava Topo        knobs: speed / blobs / bands / palette
  DNA Helix        knobs: spin / twist / distance / palette
  Op Art Moire     knobs: speed / scale / mode / palette
  Phosphor Laser   knobs: morph / figure / glow / palette
  Neon Circuit     knobs: flow / tile / rewire / palette

To install: open your board's Patterns page (http://patternflow.local/patterns)
and drop this .zip on the upload area. Don't unzip it.
Needs firmware v3.10.5 or newer.

Author:  madarswork + Claude
Licence: CC-BY-SA-4.0
